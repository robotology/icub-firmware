var group___l_m_s =
[
    [ "arm_lms_f32", "group___l_m_s.html#gae266d009e682180421601627c79a3843", null ],
    [ "arm_lms_init_f32", "group___l_m_s.html#ga9fc7adca0966ff2cec1746fca8364cee", null ],
    [ "arm_lms_init_q15", "group___l_m_s.html#ga9544cc26f18cd4465cfbed371be822b3", null ],
    [ "arm_lms_init_q31", "group___l_m_s.html#ga8d4bc251169f4b102355097a9f7530d6", null ],
    [ "arm_lms_q15", "group___l_m_s.html#gacde16c17eb75979f81b34e2e2a58c7ac", null ],
    [ "arm_lms_q31", "group___l_m_s.html#ga6a0abfe6041253a6f91c63b383a64257", null ]
];