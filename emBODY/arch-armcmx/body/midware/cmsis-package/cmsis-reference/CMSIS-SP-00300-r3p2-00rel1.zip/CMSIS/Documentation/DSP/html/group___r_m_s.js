var group___r_m_s =
[
    [ "arm_rms_f32", "group___r_m_s.html#ga0e3ab1b57da32d45388d1fa90d7fd88c", null ],
    [ "arm_rms_q15", "group___r_m_s.html#gaf5b836b72dda9e5dfbbd17c7906fd13f", null ],
    [ "arm_rms_q31", "group___r_m_s.html#gae33015fda23fc44e7ead5e5ed7e8d314", null ]
];