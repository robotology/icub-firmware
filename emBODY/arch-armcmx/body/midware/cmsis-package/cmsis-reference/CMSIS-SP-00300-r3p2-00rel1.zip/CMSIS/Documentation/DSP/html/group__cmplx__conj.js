var group__cmplx__conj =
[
    [ "arm_cmplx_conj_f32", "group__cmplx__conj.html#ga3a102aead6460ad9fcb0626f6b226ffb", null ],
    [ "arm_cmplx_conj_q15", "group__cmplx__conj.html#gaf47689ae07962acaecb8ddde556df4a4", null ],
    [ "arm_cmplx_conj_q31", "group__cmplx__conj.html#gafecc94879a383c5208ec3ef99485e4b5", null ]
];