var group__cmplx__mag =
[
    [ "arm_cmplx_mag_f32", "group__cmplx__mag.html#gae45024c497392cde2ae358a76d435213", null ],
    [ "arm_cmplx_mag_q15", "group__cmplx__mag.html#ga0a4a8f77a6a51d9b3f3b9d729f85b7a4", null ],
    [ "arm_cmplx_mag_q31", "group__cmplx__mag.html#ga14f82f9230e9d96d5b9774e2fefcb7be", null ]
];