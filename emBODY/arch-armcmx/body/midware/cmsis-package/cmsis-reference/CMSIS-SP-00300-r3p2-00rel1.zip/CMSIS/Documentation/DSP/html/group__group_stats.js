var group__group_stats =
[
    [ "Maximum", "group___max.html", "group___max" ],
    [ "Mean", "group__mean.html", "group__mean" ],
    [ "Minimum", "group___min.html", "group___min" ],
    [ "Power", "group__power.html", "group__power" ],
    [ "Root mean square (RMS)", "group___r_m_s.html", "group___r_m_s" ],
    [ "Standard deviation", "group___s_t_d.html", "group___s_t_d" ],
    [ "Variance", "group__variance.html", "group__variance" ]
];