var searchData=
[
  ['energy',['energy',['../structarm__lms__norm__instance__f32.html#a6a4119e4f39447bbee31b066deafa16f',1,'arm_lms_norm_instance_f32::energy()'],['../structarm__lms__norm__instance__q31.html#a3c0ae42869afec8555dc8e3a7ef9b386',1,'arm_lms_norm_instance_q31::energy()'],['../structarm__lms__norm__instance__q15.html#a1c81ded399919d8181026bc1c8602e7b',1,'arm_lms_norm_instance_q15::energy()']]],
  ['err_5fsignal',['err_signal',['../arm__signal__converge__example__f32_8c.html#ae6bcc00ea126543ab33d6174549eacda',1,'arm_signal_converge_example_f32.c']]],
  ['erroutput',['errOutput',['../arm__signal__converge__example__f32_8c.html#a276e8a27484cf9389dabf047e76992ed',1,'arm_signal_converge_example_f32.c']]],
  ['exemplary',['EXEMPLARY',['../license_8txt.html#ae63ad52c9dceab675153066e674486d9',1,'license.txt']]],
  ['examples',['Examples',['../group__group_examples.html',1,'']]]
];
