var searchData=
[
  ['block_5fsize',['BLOCK_SIZE',['../arm__fir__example__f32_8c.html#ad51ded0bbd705f02f73fc60c0b721ced',1,'arm_fir_example_f32.c']]],
  ['blocksize',['BLOCKSIZE',['../arm__graphic__equalizer__example__q31_8c.html#afcf795f5a96fd55561abe69f56224630',1,'BLOCKSIZE():&#160;arm_graphic_equalizer_example_q31.c'],['../arm__signal__converge__example__f32_8c.html#afcf795f5a96fd55561abe69f56224630',1,'BLOCKSIZE():&#160;arm_signal_converge_example_f32.c']]]
];
