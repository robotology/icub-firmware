var searchData=
[
  ['table_5fsize',['TABLE_SIZE',['../arm__math_8h.html#a032503e76d6f69bc67e99e909c8125da',1,'arm_math.h']]],
  ['table_5fspacing_5fq15',['TABLE_SPACING_Q15',['../arm__math_8h.html#a60b0142af7be007902142add27919b82',1,'arm_math.h']]],
  ['table_5fspacing_5fq31',['TABLE_SPACING_Q31',['../arm__math_8h.html#a8407c9e1347d10e3bcf0a7014f1fb2ff',1,'arm_math.h']]],
  ['test_5flength_5fsamples',['TEST_LENGTH_SAMPLES',['../arm__class__marks__example__f32_8c.html#abc004a7fade488e72310fd96c0a101dc',1,'TEST_LENGTH_SAMPLES():&#160;arm_class_marks_example_f32.c'],['../arm__fft__bin__example__f32_8c.html#abc004a7fade488e72310fd96c0a101dc',1,'TEST_LENGTH_SAMPLES():&#160;arm_fft_bin_example_f32.c'],['../arm__fir__example__f32_8c.html#abc004a7fade488e72310fd96c0a101dc',1,'TEST_LENGTH_SAMPLES():&#160;arm_fir_example_f32.c'],['../arm__linear__interp__example__f32_8c.html#abc004a7fade488e72310fd96c0a101dc',1,'TEST_LENGTH_SAMPLES():&#160;arm_linear_interp_example_f32.c'],['../arm__signal__converge__example__f32_8c.html#abc004a7fade488e72310fd96c0a101dc',1,'TEST_LENGTH_SAMPLES():&#160;arm_signal_converge_example_f32.c']]],
  ['testlength',['TESTLENGTH',['../arm__graphic__equalizer__example__q31_8c.html#a4f4a95eaace4e7b4e2f5243ed24f6b28',1,'arm_graphic_equalizer_example_q31.c']]],
  ['twiddlecoef',['twiddleCoef',['../arm__common__tables_8h.html#a9bf8c85e4c91b9b55818b3d650d2c761',1,'arm_common_tables.h']]]
];
