var searchData=
[
  ['test_5fsignal_5fconverge',['test_signal_converge',['../arm__signal__converge__example__f32_8c.html#a8f521e839d4fad24a4f12a18dfeae5d4',1,'arm_signal_converge_example_f32.c']]],
  ['test_5fsignal_5fconverge_5fexample',['test_signal_converge_example',['../arm__signal__converge__example__f32_8c.html#ac786d43cbc17bb09738447034ff8e22e',1,'arm_signal_converge_example_f32.c']]],
  ['tort',['TORT',['../license_8txt.html#a939bfb6f16767ac1b4ccd807a5d099a2',1,'license.txt']]]
];
