var searchData=
[
  ['direct',['DIRECT',['../license_8txt.html#ad9afdc0bba232070031f8010f3a4d6dd',1,'license.txt']]],
  ['dobitreverse',['doBitReverse',['../arm__fft__bin__example__f32_8c.html#a4d2e31c38e8172505e0a369a6898657d',1,'arm_fft_bin_example_f32.c']]]
];
