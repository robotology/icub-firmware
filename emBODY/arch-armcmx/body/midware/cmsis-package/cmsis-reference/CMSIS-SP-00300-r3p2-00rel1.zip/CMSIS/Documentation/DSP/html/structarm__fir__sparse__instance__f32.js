var structarm__fir__sparse__instance__f32 =
[
    [ "maxDelay", "structarm__fir__sparse__instance__f32.html#af8b8c775f4084c36774f06c082b4c078", null ],
    [ "numTaps", "structarm__fir__sparse__instance__f32.html#a5e19e7f234ac30a3db843352bf2a8515", null ],
    [ "pCoeffs", "structarm__fir__sparse__instance__f32.html#a04af7c738dfb0882ad102fcad501d94a", null ],
    [ "pState", "structarm__fir__sparse__instance__f32.html#a794af0916666d11cc564d6df08553555", null ],
    [ "pTapDelay", "structarm__fir__sparse__instance__f32.html#aaa54ae67e5d10c6dd0d697945c638d31", null ],
    [ "stateIndex", "structarm__fir__sparse__instance__f32.html#a57585aeca9dc8686e08df2865375a86d", null ]
];