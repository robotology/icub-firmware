var structarm__iir__lattice__instance__f32 =
[
    [ "numStages", "structarm__iir__lattice__instance__f32.html#af8de449af5efe1f30be82f9ba35587ee", null ],
    [ "pkCoeffs", "structarm__iir__lattice__instance__f32.html#aa69fcdd3775e828d450ce1bbd978fa31", null ],
    [ "pState", "structarm__iir__lattice__instance__f32.html#a30babe7815510219e6e3d28e6e4a5969", null ],
    [ "pvCoeffs", "structarm__iir__lattice__instance__f32.html#afc7c8f577e6f27d097fe55f57e707f72", null ]
];