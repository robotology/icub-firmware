var structarm__lms__instance__q15 =
[
    [ "mu", "structarm__lms__instance__q15.html#aae46129d7cfd7f1c162cc502ed0a9d49", null ],
    [ "numTaps", "structarm__lms__instance__q15.html#a0078e894f805af1b360369e619fb57b3", null ],
    [ "pCoeffs", "structarm__lms__instance__q15.html#a42f95368b94898eb82608e1113d18cab", null ],
    [ "postShift", "structarm__lms__instance__q15.html#acca5fbaef4a52ae411de24c9a0b929cf", null ],
    [ "pState", "structarm__lms__instance__q15.html#a9a575ff82c1e68cbb583083439260d08", null ]
];