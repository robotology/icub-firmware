var structarm__matrix__instance__f32 =
[
    [ "numCols", "structarm__matrix__instance__f32.html#acdd1fb73734df68b89565c54f1dd8ae2", null ],
    [ "numRows", "structarm__matrix__instance__f32.html#a23f4e34d70a82c9cad7612add5640b7b", null ],
    [ "pData", "structarm__matrix__instance__f32.html#af3917c032600a9dfd5ed4a96f074910a", null ]
];