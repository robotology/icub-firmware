
#include "cmsis_os.h"

int main (void) {
  for (;;);
}
