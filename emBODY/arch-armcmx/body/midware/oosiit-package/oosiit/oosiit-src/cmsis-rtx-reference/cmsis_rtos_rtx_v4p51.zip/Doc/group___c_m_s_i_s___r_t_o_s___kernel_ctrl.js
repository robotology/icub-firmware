var group___c_m_s_i_s___r_t_o_s___kernel_ctrl =
[
    [ "osCMSIS", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga702196bacccbb978620c736b209387f1", null ],
    [ "osFeature_MainThread", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga22f7d235bc9f783933bd5a981fd79696", null ],
    [ "osKernelSystemId", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga47cf03658f01cdffca688e9096b58289", null ],
    [ "osKernelInitialize", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga53d078a801022e202e8115c083ece68e", null ],
    [ "osKernelRunning", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#ga3b571de44cd3094c643247a7397f86b5", null ],
    [ "osKernelStart", "group___c_m_s_i_s___r_t_o_s___kernel_ctrl.html#gaab668ffd2ea76bb0a77ab0ab385eaef2", null ]
];