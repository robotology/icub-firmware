var group___c_m_s_i_s___r_t_o_s___wait =
[
    [ "osFeature_Wait", "group___c_m_s_i_s___r_t_o_s___wait.html#ga6c97d38879ae86491628f6e647639bad", null ],
    [ "osDelay", "group___c_m_s_i_s___r_t_o_s___wait.html#ga02e19d5e723bfb06ba9324d625162255", null ]
];