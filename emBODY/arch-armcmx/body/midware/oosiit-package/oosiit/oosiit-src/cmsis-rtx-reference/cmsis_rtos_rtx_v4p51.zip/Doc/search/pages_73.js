var searchData=
[
  ['system_20configuration',['System Configuration',['../_system_config.html',1,'Configure']]]
];
