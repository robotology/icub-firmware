var searchData=
[
  ['timer',['timer',['../structos_timer_def__t.html#a7107c9a80d9b4991d437133827e35839',1,'osTimerDef_t']]],
  ['tpriority',['tpriority',['../structos_thread_def__t.html#a15da8f23c6fe684b70a73646ada685e7',1,'osThreadDef_t']]]
];
