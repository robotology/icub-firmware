var searchData=
[
  ['os_5ftickfreq',['os_tickfreq',['../cmsis__os_8h.html#a680ce7340349b854fbc0a90a0268884f',1,'cmsis_os.h']]],
  ['os_5ftickus_5ff',['os_tickus_f',['../cmsis__os_8h.html#a33a880fcf33059346163f13b08810b63',1,'cmsis_os.h']]],
  ['os_5ftickus_5fi',['os_tickus_i',['../cmsis__os_8h.html#ac44ed47785e5ab664c497d188a532e4e',1,'cmsis_os.h']]]
];
