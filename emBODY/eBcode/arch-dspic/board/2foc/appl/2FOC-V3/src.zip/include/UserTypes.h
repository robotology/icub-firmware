#ifndef __TYPES_H
#define __TYPES_H

typedef signed int SFRAC16;

typedef unsigned char  BYTE;
typedef unsigned char  BOOL;

#define TRUE   1
#define FALSE  0

#define ON     1
#define OFF    0

#define UP     1
#define DOWN   0

#endif
