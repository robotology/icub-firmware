#ifndef __CRC16_H__
#define __CRC16_H__

extern unsigned short crc16(unsigned short crc, unsigned char const *buffer, int len);

#endif
